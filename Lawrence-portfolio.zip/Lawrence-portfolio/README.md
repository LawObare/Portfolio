# Lawrence Obare Portfolio

Static portfolio recreated from the supplied Figma structure. Open `index.html` directly or deploy the folder with Vercel/Netlify.

Before final publication, replace the placeholder contact links/email and add the real CV URL if needed.
